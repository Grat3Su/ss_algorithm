package main.service;

import java.util.List;

import dto.SidoDto;

public interface MainService {
	List<SidoDto>sidoList();

}
